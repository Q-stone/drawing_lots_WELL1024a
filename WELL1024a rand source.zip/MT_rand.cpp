﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "WELL1024a.h"

using namespace std;

int main(int argc, char **argv)
{
	if (argv[1] == NULL || argv[2] == NULL)
		return 1;

    int arg1 = atoi(argv[1]);
    int arg2 = atoi(argv[2]);

	if (argc <= 2)
		return 1;

    if (arg1 != 20201030)
        return 1;
	if (arg2 <= 0 || arg2 >= 2147483647)
		return 1;

	srand((unsigned)time(NULL));

	unsigned int init[32];
	for (int i = 0; i < 32; i++) {
		init[i] = rand() << 16 | rand();

	}
	InitWELLRNG1024a(init);
	printf("%d", (int)((double)WELLRNG1024a() * (arg2+1)));
	
	return 0;
}